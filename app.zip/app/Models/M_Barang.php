<?php 
namespace App\Models;

use CodeIgniter\Model;

class M_Barang extends Model
{
    protected $table = 'barang';
    protected $primaryKey = 'id_barang';
    protected $allowedFields = ['nama_barang', 'harga', 'jenis_barang', 'stok', 'foto'];

    public function updateStock($id_barang, $jumlah_barang)
    {
        $barang = $this->find($id_barang);
        $stok_baru = $barang['stok'] - $jumlah_barang;
        $this->update($id_barang, ['stok' => $stok_baru]);
    }
}

?>