<?php

namespace App\Controllers;

class Karyawan extends BaseController
{
    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->checkLogin('admin');
    }
    
    public function index()
    {
        echo view('karyawan/Karyawan');
    }

    public function TambahKaryawan()
    {
        echo view('karyawan/tambahKaryawan');
    }
    public function UbahKaryawan()
    {
        echo view('karyawan/UbahKaryawan');
    }

}