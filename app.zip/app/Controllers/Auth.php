<?php
namespace App\Controllers;

use App\Models\M_Auth;

class Auth extends BaseController
{
    public function index()
    {
        return view('Auth/login');
    }

    public function login()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $validationRules = [
            'username' => 'required',
            'password' => 'required'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->to('/')->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new M_Auth();
        $user = $model->checkCredentials($username, $password);

        if ($user) {
            $session = session();
            $session->set('logged_in', true);
            $session->set('username', $user['username']);
            $session->set('role', $user['role']);

            if ($user['role'] == 'admin') {
                return redirect()->to('/Barang');
            } else {
                return redirect()->to('/Transaksi');
            }
        } else {
            return redirect()->to('/')->withInput()->with('error', 'Username atau password salah');
        }
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/')->with('message', 'Anda telah keluar');
    }
}