<?php

namespace App\Controllers;

class Barang extends BaseController
{
    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->checkLogin();
    }

    public function index()
    {
        return view('barang/Barang');
    }

    public function TambahBarang()
    {
        return view('barang/tambahBarang');
    }

    public function UbahBarang()
    {
        return view('barang/UbahBarang');
    }
}