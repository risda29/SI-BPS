<?php

namespace App\Controllers;

use App\Models\M_Transaksi;
use App\Models\M_DetailTransaksi;
use App\Models\M_Barang;

class Transaksi extends BaseController
{
    protected $transaksiModel;
    protected $barangModel;
    protected $detailTransaksiModel;

    public function __construct()
    {
        $this->transaksiModel = new M_Transaksi();
        $this->barangModel = new M_Barang();
        $this->detailTransaksiModel = new M_DetailTransaksi();
    }

    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->checkLogin();
    }
    public function index()
    {
        $transaksiModel = new M_Transaksi();
        $data['transaksi'] = $transaksiModel->findAll();

        echo view('transaksi/Transaksi', $data);
    }

    public function detail($id_transaksi)
    {
        $transaksiModel = new M_Transaksi();
        $detailTransaksiModel = new M_DetailTransaksi();
        $barangModel = new M_Barang();

        $transaksi = $transaksiModel->find($id_transaksi);
        $detailTransaksi = $detailTransaksiModel->where('id_transaksi', $id_transaksi)->findAll();

        $barangDetails = [];
        foreach ($detailTransaksi as $detail) {
            $barang = $barangModel->find($detail['id_barang']);
            $barangDetails[] = [
                'nama_barang' => $barang['nama_barang'],
                'jumlah' => $detail['jumlah_barang'],
                'harga' => $detail['harga_total']
            ];
        }

        $data = [
            'transaksi' => $transaksi,
            'barang' => $barangDetails
        ];

        return $this->response->setJSON($data);
    }



    public function TambahTransaksi()
    {
        $barangModel = new M_Barang();
        $data['barang'] = $barangModel->findAll();
        echo view('transaksi/tambahTransaksi', $data);
    }

    public function simpanTransaksi()
    {
        $transaksiModel = new M_Transaksi();
        $detailTransaksiModel = new M_DetailTransaksi();
        $barangModel = new M_Barang();
    
        $session = session();
        $id_pengguna = $session->get('username');
    
        $jenis_transaksi = $this->request->getPost('jenis_transaksi');
        $tanggal_transaksi = $this->request->getPost('tanggal_transaksi');
    
        $id_barang = $this->request->getPost('id_barang');
        $jumlah_barang = $this->request->getPost('jumlah_barang');
        $harga_total = $this->request->getPost('harga_total');
    
        $total_harga = array_sum($harga_total);
        $total_jumlah_barang = array_sum($jumlah_barang);
    
        $dataTransaksi = [
            'tanggal_transaksi' => $tanggal_transaksi,
            'jenis_transaksi' => $jenis_transaksi,
            'jumlah_barang' => $total_jumlah_barang,
            'harga_total' => $total_harga,
            'id_pengguna' => $id_pengguna
        ];
    
        $transaksiModel->insert($dataTransaksi);
        $id_transaksi = $transaksiModel->insertID();
    
        foreach ($id_barang as $key => $id) {
            $dataDetail = [
                'id_transaksi' => $id_transaksi,
                'id_barang' => $id,
                'jumlah_barang' => $jumlah_barang[$key],
                'harga_total' => $harga_total[$key]
            ];
            $detailTransaksiModel->insert($dataDetail);
    
            $barangModel->updateStock($id, $jumlah_barang[$key]);
        }
    
        return redirect()->to('/Transaksi')->with('message', 'Transaksi berhasil ditambahkan');
    }
    


public function GetTransaksiByID($id_transaksi)
{
$transaksi = $this->transaksiModel->find($id_transaksi);
$detailTransaksi = $this->detailTransaksiModel->where('id_transaksi', $id_transaksi)->findAll();
$barang = $this->barangModel->findAll();

$data = [
'transaksi' => $transaksi,
'detailTransaksi' => $detailTransaksi,
'barang' => $barang
];

echo view('transaksi/UbahTransaksi', $data);
}

public function UbahTransaksi()
{
$id_transaksi = $this->request->getPost('id_transaksi');
$jenis_transaksi = $this->request->getPost('jenis_transaksi');
$tanggal_transaksi = $this->request->getPost('tanggal_transaksi');

$id_barang = $this->request->getPost('id_barang');
$jumlah_barang = $this->request->getPost('jumlah_barang');
$harga_total = $this->request->getPost('harga_total');

// Total harga dari semua barang
$total_harga = array_sum($harga_total);

// Total jumlah barang
$total_jumlah_barang = array_sum($jumlah_barang);

// Data transaksi
$dataTransaksi = [
'tanggal_transaksi' => $tanggal_transaksi,
'jenis_transaksi' => $jenis_transaksi,
'jumlah_barang' => $total_jumlah_barang,
'harga_total' => $total_harga,
];

// Update transaksi
$this->transaksiModel->update($id_transaksi, $dataTransaksi);

// Delete old details and update stock
$oldDetails = $this->detailTransaksiModel->where('id_transaksi', $id_transaksi)->findAll();
foreach ($oldDetails as $detail) {
$this->barangModel->updateStock($detail['id_barang'], -$detail['jumlah_barang']);
}
$this->detailTransaksiModel->where('id_transaksi', $id_transaksi)->delete();

// Insert new details and update stock
foreach ($id_barang as $key => $id) {
$dataDetail = [
'id_transaksi' => $id_transaksi,
'id_barang' => $id,
'jumlah_barang' => $jumlah_barang[$key],
'harga_total' => $harga_total[$key]
];
$this->detailTransaksiModel->insert($dataDetail);
$this->barangModel->updateStock($id, $jumlah_barang[$key]);
}

return redirect()->to('/Transaksi')->with('message', 'Transaksi berhasil diubah');
}

public function HapusTransaksi($id_transaksi)
{
    // Menghapus detail transaksi terkait
    $detailTransaksi = $this->detailTransaksiModel->where('id_transaksi', $id_transaksi)->findAll();
    foreach ($detailTransaksi as $detail) {
        // Kembalikan stok barang
        $this->barangModel->updateStock($detail['id_barang'], -$detail['jumlah_barang']);
    }
    $this->detailTransaksiModel->where('id_transaksi', $id_transaksi)->delete();

    // Menghapus transaksi
    $this->transaksiModel->delete($id_transaksi);

    return redirect()->to('/Transaksi')->with('message', 'Transaksi berhasil dihapus');
}

}