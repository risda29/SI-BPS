<?= $this->extend('Layout/index'); ?>

<?= $this->section('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Karyawan</h1>
        <a href="/TambahKaryawan" class="d-none d-sm-inline-block btn btn-primary shadow-sm">Tambah</a>
    </div>


    <!-- DataTales Example -->
    <div class="card shadow mb-4">

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Role</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Yurida</td>
                            <td>yrd123</td>
                            <td>Karyawan</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="#" data-toggle="modal" data-target="#detailModal"><button type="button"
                                            class="btn btn-outline-primary  btn-sm"><img class="fotoicontabel"
                                                src="icons/visibility.svg" alt="Detail"></button></a>
                                    <a href="#" data-toggle="modal" data-target="#deleteModal"> <button type="button"
                                            class="btn btn-outline-danger  btn-sm"><img class="fotoicontabel"
                                                src="icons/delete.svg" alt="Hapus"></button></a>
                                    <a href="/UbahKaryawan"><button type="button"
                                            class="btn btn-outline-warning  btn-sm"><img class="fotoicontabel"
                                                src="icons/edit.svg" alt="Ubah"></button></a>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Hayat</td>
                            <td>hyt123</td>
                            <td>Karyawan</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="#" data-toggle="modal" data-target="#detailModal"><button type="button"
                                            class="btn btn-outline-primary  btn-sm"><img class="fotoicontabel"
                                                src="icons/visibility.svg" alt="Detail"></button></a>
                                    <a href="#" data-toggle="modal" data-target="#deleteModal"> <button type="button"
                                            class="btn btn-outline-danger  btn-sm"><img class="fotoicontabel"
                                                src="icons/delete.svg" alt="Hapus"></button></a>
                                    <a href="/UbahKaryawan"><button type="button"
                                            class="btn btn-outline-warning  btn-sm"><img class="fotoicontabel"
                                                src="icons/edit.svg" alt="Ubah"></button></a>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Nisa</td>
                            <td>ns123</td>
                            <td>Karyawan</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="#" data-toggle="modal" data-target="#detailModal"><button type="button"
                                            class="btn btn-outline-primary  btn-sm"><img class="fotoicontabel"
                                                src="icons/visibility.svg" alt="Detail"></button></a>
                                    <a href="#" data-toggle="modal" data-target="#deleteModal"> <button type="button"
                                            class="btn btn-outline-danger  btn-sm"><img class="fotoicontabel"
                                                src="icons/delete.svg" alt="Hapus"></button></a>
                                    <a href="/UbahKaryawan"><button type="button"
                                            class="btn btn-outline-warning  btn-sm"><img class="fotoicontabel"
                                                src="icons/edit.svg" alt="Ubah"></button></a>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?= $this->endSection(); ?>