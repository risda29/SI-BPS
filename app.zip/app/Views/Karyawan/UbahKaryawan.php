<?= $this->extend('Layout/index'); ?>

<?= $this->section('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Ubah Karyawan</h1>
    </div>


    <!-- DataTales Example -->
    <div class="card shadow ">

        <div class="card-body">
            <form>
                <div class="form-row align-items-center">
                    <div class="col-md-4 mb-3">
                        <label for="validationDefault02">Password</label>
                        <input type="text" class="form-control" id="validationDefault02" value="Password" required>
                    </div>
                    <div class="btntambahform">
                        <a class="" href="/Karyawan"><button type="button"
                                class=" btn btn-secondary mb-md-n3 btnformtambah">Batal</button></a>
                        <button type="button" class=" btn btn-primary mb-md-n3 btnformtambah">Ubah</button>
                    </div>

                </div>



            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?= $this->endSection(); ?>