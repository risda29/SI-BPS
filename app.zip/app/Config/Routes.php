<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Router\RouteCollection;

$routes = Services::routes();

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// Public routes
$routes->get('/', 'Auth::index');
$routes->post('auth/login', 'Auth::login'); // Ensure this route is defined correctly
$routes->get('auth/logout', 'Auth::logout');

// Protected routes
$routes->group('', ['filter' => 'auth'], function ($routes) {
    $routes->get('Barang', 'Barang::index');
    $routes->get('Transaksi', 'Transaksi::index');
    $routes->get('/TambahBarang', 'Barang::TambahBarang');
    $routes->get('Barang/UbahBarang', 'Barang::UbahBarang');
    $routes->get('/TambahTransaksi', 'Transaksi::TambahTransaksi'); // Add this line for TambahTransaksi
    $routes->post('Transaksi/simpanTransaksi', 'Transaksi::simpanTransaksi'); // Route for saving transaction
    $routes->get('//UbahTransaksi/(:num)', 'Transaksi::GetTransaksiByID/$1');
    $routes->post('/Transaksi/UbahTransaksi', 'Transaksi::UbahTransaksi');
    $routes->get('Transaksi/Detail/(:num)', 'Transaksi::detail/$1');
    $routes->get('/HapusTransaksi/(:num)', 'Transaksi::HapusTransaksi/$1');
});

// Admin routes
$routes->group('', ['filter' => 'auth:admin'], function ($routes) {
    $routes->get('Karyawan', 'Karyawan::index');
    // Add more admin-specific routes here
});